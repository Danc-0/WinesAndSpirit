package com.example.databindingdrinks.util;


public class PreferenceKeys {

    public static final String shopping_cart = "shopping_cart";

}
