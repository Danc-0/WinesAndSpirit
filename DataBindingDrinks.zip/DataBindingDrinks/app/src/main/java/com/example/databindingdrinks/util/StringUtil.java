package com.example.databindingdrinks.util;

/**
 * Created by User on 2/7/2018.
 */

public class StringUtil {

    public static String getQuantityString(int quantity){
        return ("Qty: " + String.valueOf(quantity));
    }

    public static String convertIntToString(int value){
        return (String.valueOf(value));
    }



}









